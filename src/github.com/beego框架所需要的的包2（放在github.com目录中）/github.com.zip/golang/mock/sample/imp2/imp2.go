package imp2

type Imp2 struct{}
