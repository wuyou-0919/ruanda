# cp

[![GoDoc](https://godoc.org/github.com/cespare/cp?status.svg)](https://godoc.org/github.com/cespare/cp)

cp is a small Go package for copying files and directories.

The API may change because I want to add some options in the future (for merging with existing dirs).

It does not currently handle Windows specifically (I think it may require some special treatment).
